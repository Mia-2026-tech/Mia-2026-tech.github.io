# 个人求职主页部署与分享指南

## 方法一：使用GitHub Pages免费部署（推荐）

### 步骤1：创建GitHub账号
如果您还没有GitHub账号，请先注册：https://github.com/join

### 步骤2：创建新仓库
1. 登录GitHub后，点击右上角的"+"号，选择"New repository"
2. 仓库名称填写：`您的用户名.github.io`（例如：chenyujia.github.io）
3. 选择"Public"公开仓库
4. 勾选"Add a README file"
5. 点击"Create repository"

### 步骤3：上传文件
1. 进入刚创建的仓库
2. 点击"Add file" → "Upload files"
3. 拖拽或选择`/home/user/vibecoding/workspace/resume`目录下的所有文件
4. 拉到页面底部，点击"Commit changes"

### 步骤4：访问您的网站
上传完成后，等待1-2分钟，然后访问：`https://您的用户名.github.io`

## 方法二：使用Netlify免费部署

### 步骤1：创建Netlify账号
访问 https://app.netlify.com/signup 注册账号

### 步骤2：部署网站
1. 登录后，点击"Add new site" → "Upload files"
2. 拖拽`/home/user/vibecoding/workspace/resume`文件夹到上传区域
3. 等待部署完成

### 步骤3：获取访问链接
部署成功后，Netlify会提供一个随机的域名，您可以直接分享这个链接

## 方法三：本地文件分享

### 压缩文件
1. 在Linux/Mac终端执行：
   ```bash
   cd /home/user/vibecoding/workspace
   zip -r resume.zip resume/
   ```

2. 在Windows上：
   - 右键点击resume文件夹
   - 选择"发送到" → "压缩(zipped)文件夹"

### 分享方式
- 通过邮件附件发送
- 使用云存储服务（百度网盘、Google Drive等）
- 使用文件传输工具（WeTransfer、奶牛快传等）

## 方法四：使用Vercel部署

### 步骤1：创建Vercel账号
访问 https://vercel.com/signup 注册账号

### 步骤2：导入项目
1. 登录后，点击"New Project"
2. 选择"Import Git Repository"或直接拖拽文件
3. 按照提示完成部署

## 重要提示

1. **个人信息保护**：在分享前，请确保删除或模糊化敏感信息（如真实手机号、具体家庭地址等）
2. **测试链接**：分享前，请先在不同设备和浏览器上测试链接是否正常工作
3. **更新维护**：定期更新您的简历内容，保持信息的时效性

选择任一方法部署后，您就可以将生成的链接分享给潜在雇主、朋友或家人了！